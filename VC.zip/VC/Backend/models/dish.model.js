// STEP1: IMPORT MONGOOSE MODULE
var mongoose = require('mongoose');

// STEP2: CREATE SCHEMA OBJECT
const Schema = mongoose.Schema;

// STEP3: CREATE OUR SCHEMA WITH OPTIONALLY ADDING VALIDATIONS
// SIMPLE SCHEMA
let Dish = new Schema({
    dishName:{ type: String },       
    dishImage: { type: String },
    category:{ type: String },
    description: { type: String },
    quantity1:{ type:Number},
    quantity2:{type:Number},
    quantity3:{type:Number},
    ingredients1:{type:String},
    ingredients2:{type:String},
    ingredients3:{type:String},
    instructions1:{type:String},
    instructions2:{type:String},
    instructions3:{type:String}  
    
});
// STEP4: EXPORT SCHEMA
module.exports = mongoose.model('Dish', Dish);