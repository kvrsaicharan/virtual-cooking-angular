
const express = require('express');

const mongoose = require('mongoose');

const path=require ('path');
const config = require('../config/db');

const router = express.Router();

let Dish= require('../models/dish.model');
const multer = require('multer');
var fs = require('fs');

mongoose.connect(config.DB,
    { useNewUrlParser: true, useUnifiedTopology: true });

let db = mongoose.connection;

db.once('open', function () {
    console.log('Connection Open with MongoDB Server ..!');
});

db.on('error', function (err) {
    console.log("Error : " + err.stack);
});

const serverPath = '../public/images';

var fn;
// file uploading logic
var storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, serverPath);
    },
    filename: (req, file, cb) => {
        //let ext = path.extname(file.originalname);
        // var filename = `${file.originalname}-${new Date().getTime()}${ext}`;
        var filename = file.originalname;
        cb(null, filename);
        fn = filename;
        console.log(fn);
    }
});

//GET /api/users
router.route('/dishes').get(function (req, res) {
    Dish.find(function (err, dishes) {
        if (err) {
            res.status(500).json(err.stack);
            return;
        }
        res.status(200).json(dishes);
    });
});


    router.route('/dishes/:category')
    .get(function (req, res) {

           
            Dish.find({ category: req.params.category }, function (err, dishes) {
                if (err) {
                    res.status(500).json(err.stack);
                    
                    return;
                }
                res.status(200).json(dishes);
            });
    });

// CREATE - POST - /api/users
router.route('/dishes').post(function (req, res) {
    // var movie = new Movie();
    //  movie.movieName = req.body.movieName;
    //  movie.movieImage = req.body.movieImage;
    //  movie.certified = req.body.certified;
    //  movie.language=req.body.language;
        

    // movie.save(function (err) {
    //     if (err) {
    //         res.status(500).json(err.stack);
    //         return;
    //     }
    //     console.log("added");
    //     res.status(200).json({
    //         message
    //             : 'Movie Created !'
    //     })
    // })
    var upload = multer({ storage: storage })
    .fields([{ name: 'dishImage', maxCount: 1 }]);

upload(req, res, function (err) {
    if (err) {
        res.status(500).json(
            {
                message: "Failed to upload file",
                error: err
            });
        return;
    }
    //If upload success save user details
    var dish = new Dish(req.body);
    // if (req.files.movieImage && req.files.movieImage.length > 0) {
      //  movie.movieImage = `http://${req.get('host')}/public/images/${req.files.movieImage[0].filename}`;
        // console.log(movie.movieImage);
     //}
    
    if (req.body.dishImage && req.body.dishImage.length > 0) {
        //user.photo = `http://${req.get('host')}/public/images/${req.files.photo[0].filename}`;
        dish.dishImage = `http://${req.get('host')}/public/images/${req.body.dishImage.filename}`;
       // movie.movieImage =  `http://${req.get('host')}/public/images/${fn}`;
        console.log(dish.dishImage);
    }

    dish.save((err, doc) => {
        if (err) {
            res.status(500).json(
                {
                    message: "Error in adding movie details",
                    error: err
                });
        }
        else {
            res.status(200).json(
                {
                    message: 'Dish details added successfully',
                    movie: doc,
                    location: `/api/dishes/${doc._id}`
                });
        }
    });
});
});


// DELETE /api/users/1
router.route('/dishes/:id')
    .delete(function (req, res) {
        // remove(), findByIdAndRemove(), deleteOne()
        Dish.deleteOne({ _id: req.params.id },
            function (err, user) {
                if (err) {
                    res.status(500).json(err.stack);
                    return;
                }
                res.status(200).json({
                    message:
                        'Dish successfully deleted'
                });
            })
    });

// UPDATE - PUT /api/users/1
router.route('/dishes/:id')
    .put(function (req, res) {
        Dish.findById(req.params.id,
            function (err, dish) {
                if (err) {
                    res.status(500).json(err.stack);
                    return;
                }
    dish.dishName = req.body.dishName;
    dish.dishImage = req.body.dishImage;
    dish.category = req.body.category;
    dish.description = req.body.description; 
    dish.quantity1 = req.body.quantity1;
    dish.quantity2 = req.body.quantity2;
    dish.quantity3 = req.body.quantity3;
    dish.ingredients1 = req.body.ingredients1;
    dish.ingredients2 = req.body.ingredients2;
    dish.ingredients3 = req.body.ingredients3;
    dish.instructions1 = req.body.instructions1;
    dish.instructions2 = req.body.instructions2;
    dish.instructions3= req.body.instructions3;
    
    

                dish.save(function (err) {
                    if (err) {
                        res.status(500).json(err.stack);
                        return;
                    }

                    res.status(200).json({
                        message:
                            'Dish updated!'
                    });
                });
            });
    });
module.exports = router;