import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
// import {FileUploader,FileSelectDirective} from 'ng2-file-upload/ng2-file-upload';
import { DishService } from 'src/app/services/dish.service';


@Component({
  selector: 'app-add-dish',
  templateUrl: './add-dish.component.html',
  styleUrls: ['./add-dish.component.css']
})
export class AddDishComponent implements OnInit {

  addForm: FormGroup;
  submitted: boolean = false;


  constructor(private formBuilder: FormBuilder,
    private router: Router,
    private dishService: DishService) { }

  ngOnInit() {
    this.addForm = this.formBuilder.group({
      _id: [],
      dishName: ['', Validators.required],
      dishImage: ['', Validators.required],
      category: ['', Validators.required],
      description: ['', Validators.required],
      quantity1: ['', Validators.required],
      quantity2: ['', Validators.required],
      quantity3: ['', Validators.required],
      ingredients1: ['', Validators.required],
      ingredients2: ['', Validators.required],
      ingredients3: ['', Validators.required],
      instructions1: ['', Validators.required],
      instructions2: ['', Validators.required],
      instructions3: ['', Validators.required],
    });

    //this.dishService.uploadFile();
  }
  //uploader = this.dishService.uploader;
  // onSubmit() function
  onSubmit() {
    this.submitted = true;
    if (this.addForm.invalid) {
      return;
    }
    console.log(this.addForm.value);
    this.dishService.createDish(this.addForm.value).subscribe(data => {
        alert(this.addForm.controls.dishName.value
          + ' record is added successfully ..!');
        this.router.navigate(['user-list']);
      })
  }
}

