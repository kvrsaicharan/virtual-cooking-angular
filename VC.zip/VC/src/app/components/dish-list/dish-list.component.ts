import { Component, OnInit } from '@angular/core';
import { Dish } from 'src/app/model/dish.model';
import { Router } from '@angular/router';
import { DishService} from '../../services/dish.service';

@Component({
  selector: 'app-dish-list',
  templateUrl: './dish-list.component.html',
  styleUrls: ['./dish-list.component.css']
})
export class DishListComponent implements OnInit {

dishes: Dish[];
searchText: any;
constructor(private router: Router , private dishService: DishService) { }


ngOnInit() {
  if (localStorage.getItem("username") != null) {
    this.dishService.getdishes()
      .subscribe(data => {
        this.dishes = data;
      });
  }
  else {
    this.router.navigate(['/home']);
  }
}
deleteDish(dish: Dish): void {
  let result = confirm("Do you want to delete Dish?");
  if (result) {
    this.dishService.deleteDish(dish._id)
      .subscribe(data => {
        this.dishes = this.dishes.filter
          (u => u !== dish);
      })
    alert(`${dish.dishName} record is deleted ..!`);

    
  }
}

}
