import { Component, OnInit } from '@angular/core';
import { Dish } from 'src/app/model/dish.model';
import { Router, ActivatedRoute } from '@angular/router';
import { DishService } from '../../services/dish.service';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-user-list',
  templateUrl: './user-list.component.html',
  styleUrls: ['./user-list.component.css']
})
export class UserListComponent implements OnInit {
  dishes: Dish[];
  dish:{};
    searchText: any;
  category: string
  selectForm: FormGroup;
  submitted: boolean = false;
  invalidLogin: boolean = false;
  ingredients:string;
  instructions:string;
  constructor(private router: Router,private formBuilder:FormBuilder
    , private dishService: DishService, private route: ActivatedRoute) {
    this.route.params.subscribe(params => this.category = params['category']);

  }

  ngOnInit() {
    this. selectForm = this.formBuilder.group({
      quantity: ['', Validators.required],})
 console.log(this.category)
    this.dishService.getdishesByCategory(this.category)
      .subscribe(data => { this.dishes = data; });
  }

  getModules(dish:any) {
    console.log("In get module",dish);
    this.dishService.getdishesByCategory(dish.category).subscribe(data=>{this.dish=data;});
    let quantity=this.selectForm.controls.quantity.value;
   
   if (quantity == dish.quantity1) {
    this.ingredients=dish.ingredients1;
    this.instructions=dish.instructions1;
    }
    else if(quantity==dish.quantity2){
      this.ingredients=dish.ingredients2;
      this.instructions=dish.instructions2;
    }
    else if(quantity==dish.quantity3){
      this.ingredients=dish.ingredients3;
      this.instructions=dish.instructions3;
    }
  }
}







