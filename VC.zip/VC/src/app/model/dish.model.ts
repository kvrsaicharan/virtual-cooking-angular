export class Dish {
    _id: string;
    dishName: string;    
    dishImage: string;
    category:string;
    description:string;
    quantity1:number;
    quantity2:number;
    quantity3:number;
    ingredients1:string;
    ingredients2:string;
    ingredients3:string;
    instructions1:string;
    instructions2:string;
    instructions3:string;
    
    
}