import { Pipe, PipeTransform } from '@angular/core';
import { Dish } from '../model/dish.model';

@Pipe({
  name: 'name'
})
export class NamePipe implements PipeTransform {

  transform(dishesList: any, searchText: any) {
		let updatedDishesList: Dish[];

		if (searchText) {
			updatedDishesList = dishesList.filter(dish =>
				dish.dishName.toLowerCase()
					.startsWith(searchText.toLowerCase()));
			console.log(updatedDishesList.length);
			console.log(updatedDishesList);
		}
		else
			updatedDishesList = dishesList;

		return updatedDishesList;
	}


}

