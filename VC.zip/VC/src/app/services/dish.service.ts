import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import {Dish} from '../model/dish.model';

//import { FileUploader, FileDropDirective} from 'ng2-file-upload/ng2-file-upload';

@Injectable({
  providedIn: 'root'
})
export class DishService {

  constructor(private http:HttpClient ) { }
  baseUrl:string = "http://localhost:3000/api/dishes";
 


  // public uploader: FileUploader =
  // new FileUploader({ url: this.baseUrl, 
  //       itemAlias: 'dishImage' });

// Step7 - Upload file logic
// uploadFile() {
//   this.uploader.onAfterAddingFile =
//     (file) => { file.withCredentials = false; };

//   this.uploader.onCompleteItem =
//     (item: any, response: any,
//       status: any, headers: any) => {
//       console.log('ImageUpload:uploaded:', 
//       item, status, response);
//     }
// }
   //get all todos
   getdishes(){
    return this.http.get<Dish[]>(this.baseUrl);
  }

  //get todos by id
  getdishesByCategory(category:string){
   
    return this.http.get<Dish[]>(this.baseUrl+"/"+category);
  }

  //add todo
  createDish(dish : Dish){
    return this.http.post(this.baseUrl,dish);
    //here user in parantheses is body of user
  }

  //modify todo
  updateDish(dish:Dish){
    return this.http.put(this.baseUrl+ '/' +dish._id,dish);
  }

  //delete todo
  deleteDish(id:string){
    return this.http.delete(this.baseUrl+ "/" +id);

  }
  getdishesById(id:string){  
    return this.http.get<Dish>(this.baseUrl+  "/" +id);
  }
}
